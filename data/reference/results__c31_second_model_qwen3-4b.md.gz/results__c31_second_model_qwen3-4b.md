# C31 - the unembedding correction on a second model (qwen3-4b)

`v_y(beta) = v_y - beta * <v_y, u_hat_y> * u_hat_y` applied to the **published** J-lens, which needs no corpus, no component fit and no refit -- so this is the same correction, transferred, not a re-tuned one. `galpha` subtracts the single per-layer scalar `alpha_l = sum_y <v_y,u_y> / sum_y ||u_y||^2` instead of a per-word coefficient.

Both models on the 192 flexible-generalization trials at seven layers of their own workspace band. Denominators differ (99 vs 105 non-math trials) because the exclusion rule keeps only trials whose source answer the model produces unsteered, and the two models do not answer the same subset correctly -- so compare the RATIOS, not the raw counts.

## Non-math, published lens, both models

| beta | qwen3-4b /99 | rate | qwen3-8b /105 | rate |
|---|---|---|---|---|
| b0 | 18 | 0.182 | 20 | 0.190 |
| b0.5 | 26 | 0.263 | 28 | 0.267 |
| b1 | 40 | 0.404 | 47 | 0.448 |
| b2 | 33 | 0.333 | 35 | 0.333 |
| galpha | 37 | 0.374 | 47 | 0.448 |

## Does the shape replicate?

- **qwen3-4b**: 18 -> 40 at beta=1, a 2.22x gain; galpha 37.
- **qwen3-8b**: 20 -> 47 at beta=1, a 2.35x gain; galpha 47.

The correction is unimodal in beta on both models, peaks at beta=1 (orthogonality to `u_y`) on both, falls back by beta=2 on both, and the one-scalar `galpha` surrogate lands next to the per-word optimum on both. Nothing here was tuned on the second model.

**This is transfer across SCALE WITHIN A MODEL FAMILY, not across models in general.** Qwen3-4B and Qwen3-8B share an architecture and a tokenizer, and the correction is defined by the target token's own unembedding row -- so it is tokenizer-bound by construction. A model whose tokenizer splits these arguments differently has no corresponding `u_y` and the construction does not carry over unchanged. A different-family replication (Gemma, whose config is in this repo) is the test that would license the general claim, and it has not been run.

Written by `scripts/47_second_model.py` from `c9_domain_causal_qwen3-4b_beta4b.md`.
